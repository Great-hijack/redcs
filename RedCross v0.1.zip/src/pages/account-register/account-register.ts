import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-account-register',
  templateUrl: 'account-register.html',
})
export class AccountRegisterPage {
  ACCOUNT = {
    name: '',
    email: '',
    phone: '',
    organization: '',
    role: ''
  };
  ROLES: string[] = ['MoveAbility', 'Referral', 'Referral Lead', 'Service Provider'];
  ORGs: string[] = ['OCRC1', 'OCRC2', 'OCRC3', 'OCRC4'];
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private alertCtrl: AlertController
  ) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AccountRegisterPage');
  }

  doCancel(){
    this.navCtrl.setRoot('WelcomePage');
  }

  doSubmit(){
    console.log(this.ACCOUNT);
    const confirm = this.alertCtrl.create({
      title: 'CONFIRMATION:',
      message: 'Are you sure you want to create this account?',
      buttons: [
        {
          text: 'Disagree',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Agree',
          handler: () => {
            console.log('Agree clicked, Send to db');
          }
        }
      ]
    });
    confirm.present();
  }

}
