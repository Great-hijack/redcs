import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { iPatient } from '../../interfaces/patient.interface';
import { CrudService } from '../../services/crud.service';
import { AppService } from '../../services/app.service';
import { iLoc } from '../../interfaces/loc.interface';

@IonicPage()
@Component({
  selector: 'page-case-information-fill',
  templateUrl: 'case-information-fill.html',
})
export class CaseInformationFillPage {
  data;
  PATIENT: iPatient;
  LOCATIONS: iLoc[] = [];
  CITIES: iLoc[];
  DIST_IN_CITY: iLoc[] = [];
  YARDS_IN_DIST: iLoc[] = [];
  SELECTED_DISTRICTS: iLoc[];
  SELECTED_YARDS: iLoc[];
  toggleValue: boolean = false;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private crudService: CrudService,
    private appService: AppService
  ) {
    this.data = this.navParams.data;
    console.log(this.data);
    this.PATIENT = this.data.PATIENT;

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CaseInformationFillPage');
    this.getCities();
  }

  addPatient() {
    console.log(this.PATIENT);
  }

  getCities() {
    this.crudService.getAllCities()
      .then((res) => {
        this.CITIES = res.data().CITIES;
        console.log(this.CITIES)
      })
      .catch((err) => { console.log(err) })
  }

  selectCity(CITY: iLoc) {
    console.log(CITY);
    this.getDistrictinCity(CITY.CCODE);
  }

  getDistrictinCity(id) {
    this.crudService.getDistrictYard(id)
      .then((docSnap) => {
        this.LOCATIONS = docSnap.data().HANOI;
        console.log(this.LOCATIONS);
        this.DIST_IN_CITY = this.appService.removeDuplicateObjectFromArray(this.LOCATIONS,'DCODE');
        // this.DIST_IN_CITY = this.appService.removeDuplicateObjectFromArray(data.HANOI, 'CCODE');
        console.log(this.DIST_IN_CITY);
        // this.LOCATIONS.filter(LOC=>{
        //   return LOC.CCODE = 
        // })
        
      })
      .catch((err) => {
        console.log(err);
      })
  }

  selectDist(DIST: iLoc) {
    console.log(DIST);
    this.YARDS_IN_DIST = this.LOCATIONS.filter(loc=>{
      return loc.DCODE == DIST.DCODE
    })
    console.log(this.YARDS_IN_DIST);

  }

  selectYard(YARD: iLoc){
    console.log(YARD);
    this.PATIENT.PAT_CONTACT_LOC = YARD;
  }

  updateToggleValue(){
    console.log(this.toggleValue);
    if(this.toggleValue){
      this.PATIENT.PAT_HOME_ADDRESS = this.PATIENT.PAT_CONTACT_ADDRESS;
      this.PATIENT.PAT_HOME_YARD = this.PATIENT.PAT_CONTACT_YARD;
      this.PATIENT.PAT_HOME_DIST = this.PATIENT.PAT_CONTACT_DIST;
      this.PATIENT.PAT_HOME_CITY = this.PATIENT.PAT_CONTACT_CITY;
      this.PATIENT.PAT_HOME_LOC = this.PATIENT.PAT_CONTACT_LOC
    }
  }

}
