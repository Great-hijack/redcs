import { IonicModule } from 'ionic-angular';
import { NgModule } from '@angular/core';
import { TestOneComponent } from './test-one/test-one';
import { MyFooterComponent } from './my-footer/my-footer';
import { MyPopularCitiesComponent } from './my-popular-cities/my-popular-cities';
import { MyCompanyInfoComponent } from './my-company-info/my-company-info';
import { MyRankedGuidesComponent } from './my-ranked-guides/my-ranked-guides';
import { MyAccountManageComponent } from './my-account-manage/my-account-manage';
@NgModule({
    declarations: [
        TestOneComponent,
        MyFooterComponent,
        MyPopularCitiesComponent,
        MyCompanyInfoComponent,
        MyRankedGuidesComponent,
        MyAccountManageComponent
    ],
    imports: [IonicModule],
    exports: [
        TestOneComponent,
        MyFooterComponent,
        MyPopularCitiesComponent,
        MyCompanyInfoComponent,
        MyRankedGuidesComponent,
        MyAccountManageComponent
    ]
})
export class ComponentsModule { }
