export interface iLoc {
    CCODE: string,
    CITY: string,
    DCODE: string,
    DIST: string,
    YCODE: string,
    YARD: string
}