import { Injectable } from '@angular/core';

// import * as firebase from 'firebase/app';
// import 'firebase/auth';
// import { AngularFireService } from './af.service';

@Injectable()


export class PaymentService {
    isSigned: boolean = false;
    uid: string;
    email: string;
    constructor(
        // private afService: AngularFireService
    ) { }
    
    



}