export interface iDay {
    D_DATE: string,
    D_STATUS: string,
    D_BOOK_ID: string
}