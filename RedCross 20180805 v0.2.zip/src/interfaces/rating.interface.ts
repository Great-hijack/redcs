export interface iRating {
    RT_ID: string,
    RT_BOOK_ID: string,
    RT_STAR: number,
    RT_RATER_ID: string,
    RT_RATER_EMAIL: string,
    RT_RATER_NAME: string,
    RT_COMMENT: string 
    RT_RATEE: string,
    RT_TIMESTAMP: number,
    RT_TIME_STR: string
}