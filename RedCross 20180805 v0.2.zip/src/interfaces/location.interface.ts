export interface iLocation {
    L_COUNTRY: string,
    L_CITY: string,
    L_FLAG_IMAGE_URL
    L_ID: string,
    L_ID_STR: string
}