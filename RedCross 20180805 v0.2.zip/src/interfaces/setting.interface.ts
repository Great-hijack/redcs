export interface iSetting {
    setCafe: boolean,
    setRestaurant: boolean,
    setTakeAway: boolean,
    setHomeMade: boolean
    setOther: boolean
    language: string;
}