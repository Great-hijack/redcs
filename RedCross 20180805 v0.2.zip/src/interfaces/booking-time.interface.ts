import { iLocation } from "./location.interface";

export interface iBookingTime {
    BT_BOOK_ID: string,
    // BT_TIME: number,
    BT_STATUS: string,
    // BT_GUIDE_ID: string, 
    // BT_USER_ID: string,
    // BT_TIME_START: number,
    // BT_TIME_END: number,
    // BT_LOCATION: iLocation
}