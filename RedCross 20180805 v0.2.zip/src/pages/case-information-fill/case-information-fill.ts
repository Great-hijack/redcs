import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { iPatient } from '../../interfaces/patient.interface';
import { CrudService } from '../../services/crud.service';
import { AppService } from '../../services/app.service';
import { iLoc } from '../../interfaces/loc.interface';
import { LocalService } from '../../services/local.service';

@IonicPage()
@Component({
  selector: 'page-case-information-fill',
  templateUrl: 'case-information-fill.html',
})
export class CaseInformationFillPage {
  data;
  PATIENT: iPatient;
  ACTION: string = 'add-new';
  LOCATIONS: iLoc[] = [];
  CITIES: iLoc[];
  DISABLED_SPONSORS: string[] = [];
  DISABLED_PARTS: string[] = [];
  DISABLED_REASONS: string[] = [];
  AMPUTATION_SPONSORS: string[] = [];
  AMPUTATION_PARTS: string[] = [];
  AMPUTATION_REASONS: string[] = [];
  DIST_IN_CITY: iLoc[] = [];
  WARDS_IN_DIST: iLoc[] = [];
  SELECTED_DISTRICTS: iLoc[];
  SELECTED_WARDS: iLoc[];
  toggleValue: boolean = false;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private crudService: CrudService,
    private appService: AppService,
    private localService: LocalService
  ) {
    this.data = this.navParams.data;
    console.log(this.data);
    this.PATIENT = this.data.PATIENT;
    this.ACTION = this.data.ACTION;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CaseInformationFillPage');
    this.getData();
  }

  addPatient() {
    this.PATIENT.PAT_REFERRAL_ID = this.localService.USR.U_ID;
    this.PATIENT.PAT_REFORG = this.localService.USR.U_ORG;
    this.PATIENT.PAT_DATE_DECLARE = this.appService.getCurrentDate();

    console.log(this.PATIENT);
    this.crudService.patientCreate(this.PATIENT)
      .then((res) => {
        console.log(res);
      })
      .catch(err => console.log(err))
  }

  updatePatient(){
    console.log(this.PATIENT);
  }

  getData() {
    this.crudService.getBasicData()
      .then((res) => {
        console.log(res.data());
        this.CITIES = res.data().CITIES;
        this.DISABLED_PARTS = res.data().DISABLED_PARTS;
        this.DISABLED_REASONS = res.data().DISABLED_REASONS;
        this.DISABLED_SPONSORS = res.data().DISABLED_SPONSORS;
        this.AMPUTATION_PARTS = res.data().AMPUTATION_PARTS;
        this.AMPUTATION_REASONS = res.data().AMPUTATION_REASONS;
        this.AMPUTATION_SPONSORS = res.data().AMPUTATION_SPONSORS

      })
      .catch((err) => { console.log(err) })
  }

  selectCity(CITY: iLoc) {
    console.log(CITY);
    this.getDistrictinCity(CITY.CCODE);
  }

  getDistrictinCity(id) {
    this.crudService.getDistrictWard(id)
      .then((docSnap) => {
        this.LOCATIONS = docSnap.data().HANOI;
        console.log(this.LOCATIONS);
        this.DIST_IN_CITY = this.appService.removeDuplicateObjectFromArray(this.LOCATIONS, 'DCODE');
        // this.DIST_IN_CITY = this.appService.removeDuplicateObjectFromArray(data.HANOI, 'CCODE');
        console.log(this.DIST_IN_CITY);
        // this.LOCATIONS.filter(LOC=>{
        //   return LOC.CCODE = 
        // })

      })
      .catch((err) => {
        console.log(err);
      })
  }

  selectDist(DIST: iLoc) {
    console.log(DIST);
    this.WARDS_IN_DIST = this.LOCATIONS.filter(loc => {
      return loc.DCODE == DIST.DCODE
    })
    console.log(this.WARDS_IN_DIST);

  }

  selectWard(WARD: iLoc) {
    console.log(WARD);
    this.PATIENT.PAT_CONTACT_LOC = WARD;
  }

  updateToggleValue() {
    console.log(this.toggleValue);
    if (this.toggleValue) {
      this.PATIENT.PAT_HOME_ADDRESS = this.PATIENT.PAT_CONTACT_ADDRESS;
      this.PATIENT.PAT_HOME_WARD = this.PATIENT.PAT_CONTACT_WARD;
      this.PATIENT.PAT_HOME_DIST = this.PATIENT.PAT_CONTACT_DIST;
      this.PATIENT.PAT_HOME_CITY = this.PATIENT.PAT_CONTACT_CITY;
      this.PATIENT.PAT_HOME_LOC = this.PATIENT.PAT_CONTACT_LOC
    }
  }

}
