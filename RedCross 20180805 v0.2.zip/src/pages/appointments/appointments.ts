import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AppService } from '../../services/app.service';

@IonicPage()
@Component({
  selector: 'page-appointments',
  templateUrl: 'appointments.html',
})
export class AppointmentsPage {
  data: any;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private appService: AppService
  ) {
      this.data = this.navParams.data;
      console.log(this.data);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AppointmentsPage');
  }

  // getAppointmentsOfDate(){
  //   let today = this.appService.get
  // }

}
