import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AppService } from '../../services/app.service';
import { iPatient } from '../../interfaces/patient.interface';
import { LocalService } from '../../services/local.service';

@IonicPage()
@Component({
  selector: 'page-case-precheck',
  templateUrl: 'case-precheck.html',
})
export class CasePrecheckPage {
  PATIENT: iPatient;
  SEARCHSTR: string = '';
  EXISTING_PATIENT: boolean = false;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private appService: AppService,
    private localService: LocalService
  ) {
    this.PATIENT = this.localService.PATIENT_DEFAULT;
    console.log(this.PATIENT);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CasePrecheckPage');
  }

  checkExistance(){
    console.log(this.SEARCHSTR);
    if(this.SEARCHSTR.trim() !==''){
      // check db then return result
      this.EXISTING_PATIENT = false;
      if(!this.EXISTING_PATIENT){
        this.PATIENT.PAT_ID = this.SEARCHSTR;
        this.navCtrl.push('CaseInformationFillPage', {PATIENT: this.PATIENT})
      }else{
        this.EXISTING_PATIENT = true;
      }
    }
  }

  go2CaseDetailView(){
    // get case detail
    // go2CaseDetailView();
    console.log('go2CaseDetailView();')
  }

}
