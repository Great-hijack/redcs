import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AccountService } from '../../services/account.service';
import { iUsr } from '../../interfaces/usr.interface';
import { AppService } from '../../services/app.service';

/**
 * Generated class for the ReferralAdminPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-referral-admin',
  templateUrl: 'referral-admin.html',
})
export class ReferralAdminPage {
  data: any;
  USER: iUsr
  userExpired: boolean = true;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private accountService: AccountService,
    private appService: AppService
  ) {
    this.data = this.navParams.data;
    this.USER = this.data.USER;
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ReferralAdminPage');
    this.userExpired = this.accountService.isUserExpired(this.USER);
    if (this.userExpired ) this.navCtrl.setRoot('HomePage');
  }

  addNew(){
    this.navCtrl.push('CasePrecheckPage');
  }

  getCases(){
    this.navCtrl.push('CasesListPage');
  }

}
