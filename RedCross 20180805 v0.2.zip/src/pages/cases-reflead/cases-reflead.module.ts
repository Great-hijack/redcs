import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CasesRefleadPage } from './cases-reflead';

@NgModule({
  declarations: [
    CasesRefleadPage,
  ],
  imports: [
    IonicPageModule.forChild(CasesRefleadPage),
  ],
})
export class CasesRefleadPageModule {}
