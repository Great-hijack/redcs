export const firebaseConfig = {
    apiKey: "AIzaSyDdStrfxz7nChIXZmqVRo9jDvwi3-Oix9s",
    authDomain: "move-ability.firebaseapp.com",
    databaseURL: "https://move-ability.firebaseio.com",
    projectId: "move-ability",
    storageBucket: "move-ability.appspot.com",
    messagingSenderId: "863479813550"
};
